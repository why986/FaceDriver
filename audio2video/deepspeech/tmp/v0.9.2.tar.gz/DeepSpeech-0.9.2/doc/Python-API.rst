Python
======

.. automodule:: native_client.python

Model
-----

.. autoclass:: Model
   :members:

Stream
------

.. autoclass:: Stream
   :members:

Metadata
--------

.. autoclass:: Metadata
   :members:

CandidateTranscript
-------------------

.. autoclass:: CandidateTranscript
   :members:

TokenMetadata
-------------

.. autoclass:: TokenMetadata
   :members:
